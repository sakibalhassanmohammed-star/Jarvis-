# Add project specific ProGuard rules here.
-keep class com.king.jarvis.** { *; }
