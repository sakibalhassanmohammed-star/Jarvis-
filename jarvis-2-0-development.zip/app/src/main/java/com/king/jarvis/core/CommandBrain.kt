package com.king.jarvis.core

/**
 * Lightweight intent router for voice commands (English + Bangla keywords).
 * Real automation is executed by the AccessibilityService; this maps
 * natural language to a discrete [Intent] the workflow engine can run.
 */
object CommandBrain {

    enum class Intent { OPEN_CAPCUT, OPEN_INSHOT, RATE_OUTFIT, SCAN_OBJECT, OCR, UPLOAD_X, STOP, UNKNOWN }

    private val table = mapOf(
        Intent.OPEN_CAPCUT to listOf("capcut", "ক্যাপকাট", "open editor", "ভিডিও এডিট"),
        Intent.OPEN_INSHOT to listOf("inshot", "ইনশট"),
        Intent.RATE_OUTFIT to listOf("outfit", "fashion", "rate my", "পোশাক", "ড্রেস"),
        Intent.SCAN_OBJECT to listOf("scan", "identify", "what is this", "স্ক্যান", "এটা কি"),
        Intent.OCR to listOf("read text", "ocr", "extract", "টেক্সট পড়"),
        Intent.UPLOAD_X to listOf("post to x", "tweet", "upload", "টুইট", "আপলোড"),
        Intent.STOP to listOf("stop", "cancel", "থামো", "বন্ধ"),
    )

    fun route(raw: String): Intent {
        val text = raw.lowercase()
        for ((intent, keys) in table) {
            if (keys.any { text.contains(it) }) return intent
        }
        return Intent.UNKNOWN
    }
}
