package com.king.jarvis

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.king.jarvis.core.Permissions
import com.king.jarvis.service.JarvisForegroundService
import com.king.jarvis.ui.JarvisScreen
import com.king.jarvis.ui.theme.JarvisTheme

class MainActivity : ComponentActivity() {

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request runtime permissions up-front so the brain can start.
        permissionLauncher.launch(Permissions.runtime.map { it.key }.toTypedArray())

        // Start the always-listening foreground brain.
        val svc = Intent(this, JarvisForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, svc)
        } else {
            startService(svc)
        }

        setContent {
            JarvisTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val vm: JarvisViewModel = viewModel()
                    JarvisScreen(vm)
                }
            }
        }
    }
}
