package com.king.jarvis

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.king.jarvis.core.CommandBrain
import com.king.jarvis.core.VoiceEngine
import com.king.jarvis.core.WorkflowEngine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    val voice = VoiceEngine(app.applicationContext)
    val workflow = WorkflowEngine(viewModelScope)

    init {
        voice.init()
        // React to finalized transcripts by routing to the automation brain.
        voice.transcript
            .onEach { text -> if (text.isNotBlank()) handle(text) }
            .launchIn(viewModelScope)
    }

    fun setLanguage(lang: String) { voice.language = lang }

    fun toggleListen() {
        if (voice.listening.value) voice.stopListening() else voice.startListening()
    }

    private fun handle(text: String) {
        when (CommandBrain.route(text)) {
            CommandBrain.Intent.OPEN_CAPCUT -> {
                voice.speak(spoken("Launching CapCut and reading the timeline.", "ক্যাপকাট চালু করছি।"))
                workflow.run("CapCut edit", listOf(
                    "Launch CapCut", "Read timeline nodes", "Locate split points",
                    "Apply cut", "Insert audio track", "Export & return"
                ))
            }
            CommandBrain.Intent.OPEN_INSHOT -> {
                voice.speak(spoken("Opening InShot.", "ইনশট খুলছি।"))
                workflow.run("InShot edit", listOf("Launch InShot", "Read canvas", "Trim clip", "Render"))
            }
            CommandBrain.Intent.RATE_OUTFIT -> voice.speak(spoken(
                "Open the vision scanner and I will rate your outfit.",
                "ভিশন স্ক্যানার খুলুন, আমি আপনার পোশাক রেটিং করব।"))
            CommandBrain.Intent.SCAN_OBJECT -> voice.speak(spoken(
                "Point the camera and I will identify it.",
                "ক্যামেরা তাক করুন, আমি শনাক্ত করব।"))
            CommandBrain.Intent.OCR -> voice.speak(spoken(
                "Scanning for text.", "টেক্সট স্ক্যান করছি।"))
            CommandBrain.Intent.UPLOAD_X -> {
                voice.speak(spoken("Posting the video to X.", "ভিডিও X-এ পোস্ট করছি।"))
                workflow.run("Upload to X", listOf("Open X", "Attach video", "Compose caption", "Post"))
            }
            CommandBrain.Intent.STOP -> { workflow.cancel(); voice.speak(spoken("Stopped.", "থামলাম।")) }
            CommandBrain.Intent.UNKNOWN -> voice.speak(spoken(
                "Command not recognized, sir.", "কমান্ড বুঝিনি।"))
        }
    }

    private fun spoken(en: String, bn: String) = if (voice.language == "bn") bn else en

    override fun onCleared() {
        voice.destroy()
        super.onCleared()
    }
}
