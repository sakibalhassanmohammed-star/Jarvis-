package com.king.jarvis.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class WorkflowStep(val label: String, val done: Boolean = false)

/**
 * Paced multi-step automation runner. Runs off the main thread on
 * [Dispatchers.Default] and streams live logs + progress to the UI.
 * Emergency cancel simply cancels the running [Job].
 */
class WorkflowEngine(private val scope: CoroutineScope) {

    private val _steps = MutableStateFlow<List<WorkflowStep>>(emptyList())
    val steps: StateFlow<List<WorkflowStep>> = _steps

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running

    private var job: Job? = null

    fun run(name: String, stepLabels: List<String>) {
        cancel()
        _steps.value = stepLabels.map { WorkflowStep(it) }
        _logs.value = listOf("> initializing workflow: $name")
        _running.value = true
        job = scope.launch(Dispatchers.Default) {
            stepLabels.forEachIndexed { index, label ->
                if (!isActive) return@launch
                log("→ $label")
                delay(900) // simulate paced automation work
                _steps.value = _steps.value.mapIndexed { i, s ->
                    if (i == index) s.copy(done = true) else s
                }
                log("✓ done: $label")
            }
            log("● workflow complete")
            _running.value = false
        }
    }

    fun cancel() {
        job?.cancel()
        if (_running.value) log("✕ emergency cancel")
        _running.value = false
    }

    private fun log(line: String) {
        _logs.value = (_logs.value + line).takeLast(50)
    }
}
