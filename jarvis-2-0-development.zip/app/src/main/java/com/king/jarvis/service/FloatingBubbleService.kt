package com.king.jarvis.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.roundToInt

/**
 * Minimal non-intrusive floating overlay pill that rides over other apps
 * (requires SYSTEM_ALERT_WINDOW). Draggable; tap re-opens JARVIS.
 */
class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubble: View? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    private fun addBubble() {
        val pill = TextView(this).apply {
            text = "◉ JARVIS"
            setTextColor(Color.parseColor("#00E5FF"))
            setPadding(36, 20, 36, 20)
            setBackgroundColor(Color.parseColor("#CC050B14"))
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 240
        }

        var lastX = 0f; var lastY = 0f
        pill.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x += (e.rawX - lastX).roundToInt()
                    params.y += (e.rawY - lastY).roundToInt()
                    lastX = e.rawX; lastY = e.rawY
                    windowManager.updateViewLayout(pill, params)
                    true
                }
                else -> false
            }
        }

        bubble = pill
        windowManager.addView(pill, params)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        bubble?.let { windowManager.removeView(it) }
        super.onDestroy()
    }
}
