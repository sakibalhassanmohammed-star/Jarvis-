package com.king.jarvis.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.king.jarvis.ui.theme.Amber
import com.king.jarvis.ui.theme.Cyan
import com.king.jarvis.ui.theme.Emerald
import kotlin.math.cos
import kotlin.math.sin

/**
 * Animated arc reactor / talking-face core.
 * @param amplitude 0f..1f live audio-reactive energy driving the "woo" pulse.
 * @param speaking widens the core when JARVIS is talking or automating.
 */
@Composable
fun ArcReactor(
    amplitude: Float,
    speaking: Boolean,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "reactor")

    val ringA by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing)),
        label = "ringA"
    )
    val ringB by transition.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing)),
        label = "ringB"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.9f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Canvas(modifier = modifier.size(280.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val base = size.minDimension / 2f
        val energy = (0.6f + amplitude * 0.8f) * (if (speaking) 1.15f else 1f) * pulse

        // Outer photon particle ring
        rotate(ringA, pivot = Offset(cx, cy)) {
            val count = 48
            for (i in 0 until count) {
                val a = (2 * Math.PI * i / count).toFloat()
                val r = base * 0.94f
                val px = cx + r * cos(a)
                val py = cy + r * sin(a)
                val dotR = 2.5f + (if (i % 4 == 0) amplitude * 8f else 0f)
                drawCircle(
                    color = if (i % 6 == 0) Amber else Cyan,
                    radius = dotR,
                    center = Offset(px, py),
                    alpha = 0.85f
                )
            }
        }

        // Concentric rotational rings
        rotate(ringB, pivot = Offset(cx, cy)) {
            drawCircle(
                color = Cyan, radius = base * 0.78f,
                center = Offset(cx, cy),
                style = Stroke(width = 6f)
            )
            for (i in 0 until 12) {
                val a = (2 * Math.PI * i / 12).toFloat()
                val r0 = base * 0.66f
                val r1 = base * 0.78f
                drawLine(
                    color = Emerald,
                    start = Offset(cx + r0 * cos(a), cy + r0 * sin(a)),
                    end = Offset(cx + r1 * cos(a), cy + r1 * sin(a)),
                    strokeWidth = 4f, cap = StrokeCap.Round
                )
            }
        }

        rotate(ringA * 0.6f, pivot = Offset(cx, cy)) {
            drawArc(
                color = Amber,
                startAngle = 0f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - base * 0.6f, cy - base * 0.6f),
                size = androidx.compose.ui.geometry.Size(base * 1.2f, base * 1.2f),
                style = Stroke(width = 5f, cap = StrokeCap.Round)
            )
            drawArc(
                color = Cyan,
                startAngle = 180f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - base * 0.6f, cy - base * 0.6f),
                size = androidx.compose.ui.geometry.Size(base * 1.2f, base * 1.2f),
                style = Stroke(width = 5f, cap = StrokeCap.Round)
            )
        }

        // Live audio waveform reactive geometry (radial spikes)
        val spikes = 64
        for (i in 0 until spikes) {
            val a = (2 * Math.PI * i / spikes).toFloat()
            val wobble = (sin(a * 6 + ringA * 0.05f) + 1f) / 2f
            val len = base * (0.30f + wobble * amplitude * 0.22f)
            val r0 = base * 0.30f
            drawLine(
                color = Cyan.copy(alpha = 0.7f),
                start = Offset(cx + r0 * cos(a), cy + r0 * sin(a)),
                end = Offset(cx + (r0 + len) * cos(a), cy + (r0 + len) * sin(a)),
                strokeWidth = 3f
            )
        }

        // Pulsating holographic core (the mouth / energy heart)
        val coreR = base * 0.24f * energy
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Cyan, Cyan.copy(alpha = 0f)),
                center = Offset(cx, cy), radius = coreR * 2.2f
            ),
            radius = coreR * 2.2f, center = Offset(cx, cy)
        )
        drawCircle(color = Color.White, radius = coreR, center = Offset(cx, cy))
    }
}
