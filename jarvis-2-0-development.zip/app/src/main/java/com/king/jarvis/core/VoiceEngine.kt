package com.king.jarvis.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/**
 * Dual-language (English + Bangla) voice recognition + synthesis engine.
 * Recognition and callbacks are posted to the main looper by the platform;
 * all heavy work is delegated to coroutines by the caller so the UI never blocks.
 */
class VoiceEngine(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript

    private val _listening = MutableStateFlow(false)
    val listening: StateFlow<Boolean> = _listening

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude

    /** "en" or "bn". Automatic re-detection happens on each utterance. */
    var language: String = "en"

    fun init(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = localeFor(language)
                onReady()
            }
        }
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(listener)
            }
        }
    }

    private fun localeFor(lang: String): Locale =
        if (lang == "bn") Locale("bn", "BD") else Locale.US

    fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeFor(language).toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        _listening.value = true
        recognizer?.startListening(intent)
    }

    fun stopListening() {
        _listening.value = false
        recognizer?.stopListening()
    }

    fun speak(text: String) {
        _speaking.value = true
        tts?.language = localeFor(language)
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) { _speaking.value = true }
            override fun onDone(id: String?) { _speaking.value = false }
            @Deprecated("deprecated in API level 21")
            override fun onError(id: String?) { _speaking.value = false }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-utt")
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            // Normalize RMS (-2..12 dB) into 0..1 for the audio-reactive core.
            _amplitude.value = ((rmsdB + 2f) / 14f).coerceIn(0f, 1f)
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { _amplitude.value = 0f }
        override fun onError(error: Int) {
            _listening.value = false
            _amplitude.value = 0f
        }
        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            if (text.isNotBlank()) _transcript.value = text
            _listening.value = false
        }
        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            if (text.isNotBlank()) _transcript.value = text
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    fun destroy() {
        recognizer?.destroy()
        tts?.shutdown()
    }
}
