package com.king.jarvis.core

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

data class PermissionItem(
    val key: String,
    val title: String,
    val rationale: String,
)

object Permissions {

    val runtime: List<PermissionItem> = buildList {
        add(PermissionItem(Manifest.permission.RECORD_AUDIO, "Microphone", "Continuous speech & voice activation"))
        add(PermissionItem(Manifest.permission.CAMERA, "Camera", "Sensory scanner, item recognition & outfit rating"))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(PermissionItem(Manifest.permission.POST_NOTIFICATIONS, "Notifications", "Foreground service status alerts"))
        }
    }

    fun openAccessibilitySettings(ctx: Context) =
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })

    fun openOverlaySettings(ctx: Context) =
        ctx.startActivity(Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${ctx.packageName}")
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })

    fun canDrawOverlays(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)
}
