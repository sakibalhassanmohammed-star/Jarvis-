package com.king.jarvis.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Obsidian = Color(0xFF050B14)
val Cyan = Color(0xFF00E5FF)
val Amber = Color(0xFFFF9100)
val Emerald = Color(0xFF00E676)
val SurfaceDark = Color(0xFF0A1622)

private val JarvisColors = darkColorScheme(
    primary = Cyan,
    secondary = Emerald,
    tertiary = Amber,
    background = Obsidian,
    surface = SurfaceDark,
    onPrimary = Obsidian,
    onBackground = Cyan,
    onSurface = Cyan,
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisColors,
        content = content
    )
}
