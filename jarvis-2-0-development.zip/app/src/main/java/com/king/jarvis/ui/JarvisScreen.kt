package com.king.jarvis.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.king.jarvis.JarvisViewModel
import com.king.jarvis.ui.theme.Amber
import com.king.jarvis.ui.theme.Cyan
import com.king.jarvis.ui.theme.Emerald
import com.king.jarvis.ui.theme.Obsidian
import com.king.jarvis.ui.theme.SurfaceDark

@Composable
fun JarvisScreen(vm: JarvisViewModel) {
    val listening by vm.voice.listening.collectAsStateWithLifecycle()
    val speaking by vm.voice.speaking.collectAsStateWithLifecycle()
    val amplitude by vm.voice.amplitude.collectAsStateWithLifecycle()
    val transcript by vm.voice.transcript.collectAsStateWithLifecycle()
    val logs by vm.workflow.logs.collectAsStateWithLifecycle()
    val running by vm.workflow.running.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Obsidian, Color_0A1622, Obsidian))
            )
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "JARVIS 2.0",
                color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                if (running) "CPU ▮▮▮▮ AUTO" else "CPU ▮ IDLE",
                color = if (running) Amber else Emerald,
                fontFamily = FontFamily.Monospace, fontSize = 12.sp
            )
        }

        Spacer(Modifier.height(8.dp))
        Text("THE KING · autonomous companion", color = Emerald, fontSize = 11.sp,
            fontFamily = FontFamily.Monospace)

        Spacer(Modifier.height(12.dp))

        Box(contentAlignment = Alignment.Center) {
            ArcReactor(amplitude = amplitude, speaking = speaking || running)
        }

        Spacer(Modifier.height(8.dp))
        Text(
            when {
                speaking -> "◉ SPEAKING…"
                listening -> "◉ LISTENING…"
                running -> "◉ AUTOMATING…"
                else -> "TAP MIC OR SPEAK"
            },
            color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 13.sp
        )

        if (transcript.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text("\"$transcript\"", color = Amber, fontSize = 13.sp,
                fontFamily = FontFamily.Monospace)
        }

        // Language toggle (EN / BN)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LangChip("EN", true) { vm.setLanguage("en") }
            LangChip("বাংলা", false) { vm.setLanguage("bn") }
        }

        Spacer(Modifier.height(16.dp))

        // Terminal / live log panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceDark)
                .border(1.dp, Cyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                .padding(12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("jarvis@king:~$", color = Emerald, fontSize = 12.sp,
                fontFamily = FontFamily.Monospace)
            logs.forEach { line ->
                Text(
                    line,
                    color = if (line.startsWith("✓") || line.startsWith("●")) Emerald
                    else if (line.startsWith("✕")) Amber else Cyan,
                    fontSize = 12.sp, fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // Persistent control hub
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            QuickAction("Scan") { vm.workflow.run("Vision scan", listOf("Open camera", "Detect object", "Report")) }
            MicButton(listening) { vm.toggleListen() }
            QuickAction(if (running) "Cancel" else "Editor") {
                if (running) vm.workflow.cancel()
                else vm.workflow.run("CapCut edit",
                    listOf("Launch CapCut", "Read timeline", "Apply cut", "Insert audio", "Export"))
            }
        }
    }
}

private val Color_0A1622 = androidx.compose.ui.graphics.Color(0xFF0A1622)

@Composable
private fun MicButton(listening: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .background(if (listening) Amber else Cyan)
            .border(3.dp, Emerald, CircleShape)
            .padding(22.dp),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            if (listening) Icons.Filled.Stop else Icons.Filled.Mic,
            contentDescription = "microphone",
            tint = Obsidian
        )
    }
}

@Composable
private fun QuickAction(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark, contentColor = Cyan),
        shape = RoundedCornerShape(12.dp)
    ) { Text(label, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
}

@Composable
private fun LangChip(label: String, primary: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) Cyan.copy(alpha = 0.15f) else SurfaceDark,
            contentColor = Cyan
        ),
        shape = RoundedCornerShape(20.dp)
    ) { Text(label, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
}
