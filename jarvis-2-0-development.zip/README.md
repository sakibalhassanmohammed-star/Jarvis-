# JARVIS 2.0 — The King

Autonomous, voice-driven AI companion for Android. Jetpack Compose + Kotlin Coroutines/Flow + Material 3.

Cyberpunk Iron Man HUD: animated arc reactor core with rotating rings, photon
particles, and a live audio-reactive waveform that pulses when JARVIS speaks
or automates. Dual-language voice (English + Bangla), an `AccessibilityService`
for autonomous screen reading + gesture dispatch, a floating overlay bubble,
an always-listening foreground brain, a paced multi-step workflow engine, and
a live terminal log panel.

## How to get an installable APK

This project cannot be compiled inside the v0 web sandbox (no Android SDK). Use
either path below to produce a real `app/build/outputs/apk/debug/app-debug.apk`.

### Option 1 — GitHub Actions (no local setup, gives a download link)
1. Push this project to a GitHub repo (v0 → GitHub, or `git push`).
2. The included workflow `.github/workflows/build-apk.yml` runs automatically.
3. Open the repo's **Actions** tab → latest **Build JARVIS 2.0 Debug APK** run.
4. Download the **jarvis-2.0-debug-apk** artifact — that ZIP contains the APK.

### Option 2 — Android Studio (local)
1. Open the project in Android Studio (Giraffe+).
2. Let it sync Gradle, then **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Find it at `app/build/outputs/apk/debug/app-debug.apk`.

Command line: `./gradlew assembleDebug`

## Enabling the autonomous features on-device
- Grant Microphone + Camera when prompted at launch.
- Settings → Accessibility → **JARVIS Autonomous Control** → enable (screen
  reading + programmatic taps).
- Allow **Display over other apps** for the floating bubble overlay.

## Platform reality check
Cross-app automation of CapCut / InShot etc. relies on Android's
`AccessibilityService` + `SYSTEM_ALERT_WINDOW`, which only work on a physical
device/emulator — not in any web preview. The AI vision/outfit-rating and X
upload steps are scaffolded as workflows; wire them to your model/API keys of
choice inside `JarvisViewModel`.
